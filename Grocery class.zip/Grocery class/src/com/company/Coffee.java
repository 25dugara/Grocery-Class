package com.company;

public class Coffee extends Item{

    public Coffee(String typeOfCoffee) {
        super(typeOfCoffee, 5, 5, 100, 10);

    }
}