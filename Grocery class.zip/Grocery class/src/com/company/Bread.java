package com.company;

public class Bread extends Item
{
    public Bread() {
        super("bread", 5, 5, 20, 2);
    }
}