package com.company;

public class Main {

    public static void main(String[] args)
    {
	Cereal c = new Cereal("Rasian Bran");
	c.buy(20);
    }
}
