package com.company;

public class Cereal extends Item
{
    public Cereal(String typeOfCereal)
    {
        super(typeOfCereal, 5, 5, 100, 20);
    }
}